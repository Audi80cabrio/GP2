#include "ufo_thread.h"
#include <iostream>

UfoThread::UfoThread(Ufo* pUfo){

}
UfoThread::~UfoThread(){

}
void UfoThread::startUfo(const float x, const float y, const float height, const int speed){
if (flyThread == nullptr)
{
    std::cout << "es existiert schon ein flythread" << '\n';
}else{
    flyThread = new std::thread(&UfoThread::runner, this, x, y, height, speed);
    if (flyThread && flyThread->joinable()) {
        flyThread->join();
        flyThread = nullptr;
    }
}

}

bool UfoThread::getIsFlying() const{
    return isFlying;
}
void UfoThread::runner(const float x, const float y, const float height, const int speed){
    ufo->flyToDest(x, y, height, speed);
}
